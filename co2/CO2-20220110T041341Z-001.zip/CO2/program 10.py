# Generate all factores of a number

number=int(input("Enter a number : "))
for i in range(1,number+1):
    if number%i==0:
        print(i)